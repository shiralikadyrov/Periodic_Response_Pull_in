"""Timing comparison of the Sturm layer against shooting (Table 7 of the article).

Loads the production library cells (1-17) of notebooks/01_master_analysis.ipynb,
then times candidate generation over 16 loads lambda = k/1000, k = 5,7,...,35,
at rho = 3/10, Omega = beta = 1, M = 4 (zeta0 = 1e-2 for shooting).

Usage:  python scripts/timing_benchmark.py      (writes results/timing_benchmark_*.csv)
"""
import json, os, time, platform, sys
from pathlib import Path
from dataclasses import replace

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("CNSNS_RUN_PROFILE", "review")
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".mplcache"))
nb = json.loads((ROOT / "notebooks" / "01_master_analysis.ipynb").read_text())
g = {"__name__": "cnsns_lib"}
for i in range(1, 18):
    cell = nb["cells"][i]
    if cell["cell_type"] == "code":
        src = "".join(cell["source"]).replace('"/mnt/data/CNSNS_second_revision_outputs"', repr(str(ROOT / "results" / "notebook_outputs")))
        exec(compile(src, f"master_cell_{i}", "exec"), g)
globals().update({k: v for k, v in g.items() if not k.startswith("__")})

import numpy as np, pandas as pd, sympy as sp

lam_q = [sp.Rational(k, 1000) for k in range(5, 36, 2)]
A_MAX = sp.Rational(9, 10)
rows = []

def record(method, lam, found, sec):
    rows.append(dict(method=method, lam=float(lam), found=int(found), sec=float(sec)))

# S1: exact construction + exact root count per load
for lq in lam_q:
    t = time.perf_counter()
    ex = build_exact_surrogate(4, lam=str(lq))
    Po, _ = strip_endpoint_factor(ex["P_sqf"], ex["a"], 0)
    n = int(sp.count_roots(Po.as_expr(), 0, A_MAX))
    record("S1 exact Sturm, per-point construction", lq, n, time.perf_counter() - t)

# S2: parametric resultant in lambda once, then substitution + exact count
t = time.perf_counter()
sym = build_symbolic_surrogate_with_lambda(4)
aa, ell = sym["a"], sym["ell"]
Ppar = sp.Poly(sp.expand(sym["P"]), aa, ell, domain=sp.QQ)
setup_S2 = time.perf_counter() - t
for lq in lam_q:
    t = time.perf_counter()
    Pl = sp.Poly(Ppar.as_expr().subs(ell, lq), aa, domain=sp.QQ)
    Pl = sp.Poly(Pl.primitive()[1], aa, domain=sp.QQ).sqf_part()
    Pl, _ = strip_endpoint_factor(Pl, aa, 0)
    n = int(sp.count_roots(Pl.as_expr(), 0, A_MAX))
    record("S2 exact Sturm, parametric resultant", lq, n, time.perf_counter() - t)

# S3: exact count + numerical recovery + admissibility filter
for lq in lam_q:
    t = time.perf_counter()
    ex = build_exact_surrogate(4, lam=str(lq))
    rep = exact_sturm_report(ex, manual_chain=False, eps_power=12)
    rec = recover_physical_resultant_roots(ex, rep)
    record("S3 exact Sturm + root recovery/admissibility", lq, int(rec["admissible"].sum()), time.perf_counter() - t)

# H1: blind multi-start Newton shooting, 6x6 seeds on D = [0,0.7] x [-1,1]
seeds = [(u, v) for u in np.linspace(0, 0.7, 6) for v in np.linspace(-1, 1, 6)]
for lq in lam_q:
    p = ModelParameters(lam=float(lq)); t = time.perf_counter(); sols = []
    for z in seeds:
        s = solve_shooting(p, z)
        if s["success"] and not any(np.linalg.norm(s["z0"] - o) < 1e-6 for o in sols):
            sols.append(s["z0"])
    record("H1 multistart shooting 6x6", lq, len(sols), time.perf_counter() - t)

# H2: pseudo-arclength shooting continuation once, then per-lambda correction
t = time.perf_counter()
curve = build_reference_shooting_curve(ModelParameters(lam=0.005), ODEOptions(), n_steps=40)
setup_H2 = time.perf_counter() - t
for lq in lam_q:
    t = time.perf_counter()
    sols = shooting_orbits_at_lambda(curve, ModelParameters(lam=0.005), float(lq))
    record("H2 shooting continuation + correction", lq, len(sols), time.perf_counter() - t)

bench = pd.DataFrame(rows)
setup = {"S2 exact Sturm, parametric resultant": setup_S2, "H2 shooting continuation + correction": setup_H2}
summ = bench.groupby("method").agg(total_s=("sec", "sum"), median_per_point_s=("sec", "median"),
                                   found_min=("found", "min"), found_max=("found", "max")).reset_index()
summ["setup_s"] = summ.method.map(setup).fillna(0.0)
summ["total_incl_setup_s"] = summ.total_s + summ.setup_s
out = ROOT / "results"; out.mkdir(exist_ok=True)
bench.to_csv(out / "timing_benchmark_points.csv", index=False)
summ.to_csv(out / "timing_benchmark_summary.csv", index=False)
print(summ.round(3).to_string())
print(platform.platform(), platform.machine(), os.cpu_count(), sys.version.split()[0],
      np.__version__, sp.__version__)
